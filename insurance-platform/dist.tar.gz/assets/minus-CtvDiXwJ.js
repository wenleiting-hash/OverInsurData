import{C as a}from"./index-CO9dj1fP.js";var e=[["path",{d:"M5 12h14",key:"1ays0h"}]],r=a("minus",e);export{r as t};
