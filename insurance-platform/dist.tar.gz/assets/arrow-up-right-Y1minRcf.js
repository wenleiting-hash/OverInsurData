import{C as r}from"./index-CO9dj1fP.js";var a=[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]],o=r("arrow-up-right",a);export{o as t};
