import{C as e}from"./index-CO9dj1fP.js";var o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],t=e("chevron-left",o);export{t};
