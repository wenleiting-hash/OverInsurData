import{C as e}from"./index-CO9dj1fP.js";var r=[["circle",{cx:"15",cy:"12",r:"3",key:"1afu0r"}],["rect",{width:"20",height:"14",x:"2",y:"5",rx:"7",key:"g7kal2"}]],c=e("toggle-right",r);export{c as t};
