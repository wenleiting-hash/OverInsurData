import{C as c}from"./index-CO9dj1fP.js";var e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],r=c("clock",e);export{r as t};
