import{C as c}from"./index-CO9dj1fP.js";var e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16 9-5.5 5.5L8 12",key:"xofnsj"}]],a=c("circle-check",e);export{a as t};
