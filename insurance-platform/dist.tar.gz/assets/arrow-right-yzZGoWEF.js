import{C as r}from"./index-CO9dj1fP.js";var a=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],t=r("arrow-right",a);export{t};
