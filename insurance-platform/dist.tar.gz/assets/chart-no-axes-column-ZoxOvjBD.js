import{C as a}from"./index-CO9dj1fP.js";var e=[["path",{d:"M5 21v-6",key:"1hz6c0"}],["path",{d:"M12 21V3",key:"1lcnhd"}],["path",{d:"M19 21V9",key:"unv183"}]],t=a("chart-no-axes-column",e);export{t};
