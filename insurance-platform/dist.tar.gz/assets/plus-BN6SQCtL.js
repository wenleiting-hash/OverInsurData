import{C as a}from"./index-CO9dj1fP.js";var e=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],r=a("plus",e);export{r as t};
