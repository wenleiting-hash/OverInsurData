import {
  Controller, Get, Post, Body, Req, UseGuards,
} from '@nestjs/common';
import { IntegrationService } from './integration.service';
import { IntegrationAuthGuard } from '../../common/guards/integration-auth.guard';

/**
 * V1.0.16 workOS 集成对外接口（S2S）
 * 全部由 IntegrationAuthGuard 校验：appKey + HMAC-SHA256 + 时间戳 + nonce + IP 白名单
 *  - I1 GET  /api/integration/v1/permission-catalog
 *  - I2 POST /api/integration/v1/users/upsert
 *  - I3 POST /api/integration/v1/consultation/match
 */
@UseGuards(IntegrationAuthGuard)
@Controller('api/integration/v1')
export class IntegrationV1Controller {
  constructor(private readonly integrationService: IntegrationService) {}

  /** I1: 权限目录 */
  @Get('permission-catalog')
  async catalog() {
    const data = await this.integrationService.getPermissionCatalog();
    return { success: true, data };
  }

  /** I2: 用户/角色同步 upsert */
  @Post('users/upsert')
  async upsert(@Body() dto: any, @Req() req: any) {
    const appKey: string = req.integrationApp?.app_key;
    const operatorId: string | undefined = req.headers['x-operator-id'];
    const data = await this.integrationService.upsertUser(dto, appKey, operatorId);
    return { success: true, data };
  }

  /** I3: 保单咨询匹配 */
  @Post('consultation/match')
  async match(@Body() dto: any, @Req() req: any) {
    const appKey: string = req.integrationApp?.app_key;
    const data = await this.integrationService.matchConsultation(dto, appKey);
    return { success: true, data };
  }
}
