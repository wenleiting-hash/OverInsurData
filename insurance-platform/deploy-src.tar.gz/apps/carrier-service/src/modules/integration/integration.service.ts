import {
  Injectable, NotFoundException, ConflictException, BadRequestException,
  Logger,
} from '@nestjs/common';
import { pool } from '../../database/drizzle.client';
import { CryptoService } from '../../common/services/crypto.service';
import { AuditService } from '../../common/services/audit.service';
import { CreateIntegrationAppDto, UpdateIntegrationAppDto } from './dtos/integration.dto';
import { randomBytes, randomUUID } from 'crypto';

@Injectable()
export class IntegrationService {
  private readonly logger = new Logger(IntegrationService.name);

  constructor(
    private readonly cryptoService: CryptoService,
    private readonly auditService: AuditService,
  ) {}

  /** 生成 appKey: 前缀 + 20 位随机 base62 */
  private generateAppKey(prefix = 'wkos'): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const buf = randomBytes(20);
    let s = '';
    for (let i = 0; i < 20; i++) s += chars[buf[i] % chars.length];
    return `${prefix}_${s}`;
  }

  /** 生成 appSecret: 32 位随机 base62 */
  private generateAppSecret(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const buf = randomBytes(32);
    let s = '';
    for (let i = 0; i < 32; i++) s += chars[buf[i] % chars.length];
    return s;
  }

  /** 创建应用：返回明文 appKey + appSecret（仅一次） */
  async createApp(dto: CreateIntegrationAppDto, operator: string) {
    const appKey = this.generateAppKey();
    const appSecret = this.generateAppSecret();
    const appSecretEnc = this.cryptoService.encrypt(appSecret);

    const result = await pool.query(
      `INSERT INTO integration_app
         (app_key, app_secret_hash, app_name, app_desc, ip_whitelist, rate_limit, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING app_id, app_key, app_name, app_desc, status, ip_whitelist, rate_limit, created_at`,
      [appKey, appSecretEnc, dto.appName, dto.appDesc ?? null, dto.ipWhitelist ?? null, dto.rateLimit ?? 60, operator],
    );
    const row = result.rows[0];
    return {
      ...row,
      app_secret: appSecret, // 明文，仅本次返回
    };
  }

  /** 列表 */
  async listApps(page = 1, size = 20) {
    const offset = (page - 1) * size;
    const countResult = await pool.query(`SELECT count(*) FROM integration_app`);
    const total = parseInt(countResult.rows[0].count, 10);
    const result = await pool.query(
      `SELECT app_id, app_key, app_name, app_desc, status, ip_whitelist, rate_limit, created_by, created_at, updated_at, last_called_at
         FROM integration_app ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
      [size, offset],
    );
    return { items: result.rows, total, page, size };
  }

  /** 详情 */
  async getApp(appId: string) {
    const result = await pool.query(
      `SELECT app_id, app_key, app_name, app_desc, status, ip_whitelist, rate_limit, created_by, created_at, updated_at, last_called_at
         FROM integration_app WHERE app_id = $1`,
      [appId],
    );
    if (result.rows.length === 0) throw new NotFoundException('应用不存在');
    return result.rows[0];
  }

  /** 更新 */
  async updateApp(appId: string, dto: UpdateIntegrationAppDto) {
    await this.getApp(appId);
    const sets: string[] = [];
    const values: any[] = [];
    let i = 1;
    for (const [k, v] of Object.entries(dto)) {
      if (v === undefined) continue;
      const col = k.replace(/([A-Z])/g, '_$1').toLowerCase();
      sets.push(`${col} = $${i}`);
      values.push(v);
      i++;
    }
    if (sets.length === 0) return this.getApp(appId);
    sets.push(`updated_at = NOW()`);
    values.push(appId);
    const result = await pool.query(
      `UPDATE integration_app SET ${sets.join(', ')} WHERE app_id = $${i} RETURNING app_id, app_key, app_name, app_desc, status, ip_whitelist, rate_limit, created_at, updated_at`,
      values,
    );
    return result.rows[0];
  }

  /** 重置密钥：简单模式，新密钥立即生效，旧密钥失效 */
  async resetSecret(appId: string, operator: string) {
    await this.getApp(appId);
    const appSecret = this.generateAppSecret();
    const appSecretEnc = this.cryptoService.encrypt(appSecret);
    const result = await pool.query(
      `UPDATE integration_app SET app_secret_hash = $1, updated_at = NOW() WHERE app_id = $2
         RETURNING app_id, app_key, app_name, updated_at`,
      [appSecretEnc, appId],
    );
    return { ...result.rows[0], app_secret: appSecret, reset_by: operator };
  }

  /**
   * 查看明文 appSecret（V1.0.16：补"后续可复制"能力）
   * - 仅返回明文，不改库
   * - 调用方需记录审计日志（INTEGRATION_APP_SECRET_VIEW）
   * - 限已配置 JwtAuthGuard 的管理路由使用，不可对外暴露
   */
  async revealSecret(appId: string) {
    const result = await pool.query(
      `SELECT app_id, app_key, app_name, app_secret_hash, status FROM integration_app WHERE app_id = $1`,
      [appId],
    );
    if (result.rows.length === 0) throw new NotFoundException('应用不存在');
    const row = result.rows[0];
    const plainSecret = this.cryptoService.decrypt(row.app_secret_hash);
    return {
      app_id: row.app_id,
      app_key: row.app_key,
      app_name: row.app_name,
      status: row.status,
      app_secret: plainSecret,
    };
  }

  /** 删除 */
  async deleteApp(appId: string) {
    const result = await pool.query(`DELETE FROM integration_app WHERE app_id = $1 RETURNING app_id`, [appId]);
    if (result.rows.length === 0) throw new NotFoundException('应用不存在');
    return { success: true };
  }

  /** 根据 appKey 查询（鉴权守卫用，含加密的 secret） */
  async getAppByKey(appKey: string) {
    const result = await pool.query(
      `SELECT app_id, app_key, app_secret_hash, app_name, status, ip_whitelist, rate_limit
         FROM integration_app WHERE app_key = $1`,
      [appKey],
    );
    return result.rows[0] || null;
  }

  /** 解密 appSecret（鉴权守卫计算 HMAC 用） */
  decryptAppSecret(encrypted: string): string {
    return this.cryptoService.decrypt(encrypted);
  }

  /** 记录 nonce（防重放），返回 false 表示已存在 */
  async recordNonce(nonce: string, appKey: string, ttlSeconds = 600): Promise<boolean> {
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
    try {
      await pool.query(
        `INSERT INTO integration_nonce (nonce, app_key, expires_at) VALUES ($1, $2, $3)`,
        [nonce, appKey, expiresAt],
      );
      return true;
    } catch {
      return false;
    }
  }

  /** 更新最后调用时间 */
  async touchLastCalled(appKey: string) {
    await pool.query(`UPDATE integration_app SET last_called_at = NOW() WHERE app_key = $1`, [appKey]);
  }

  /** 清理过期 nonce（可定时调用） */
  async cleanupExpiredNonces() {
    await pool.query(`DELETE FROM integration_nonce WHERE expires_at < NOW()`);
  }

  // ─────────────────────────────────────────────────────────────
  //  I1 / I2 / I3 业务接口（V1.0.16 T3+T4+T5）
  // ─────────────────────────────────────────────────────────────

  /**
   * I1: 权限目录
   * 按 subsystem_key 分组聚合 auth_role。
   * 输出：{ version, generated_at, subsystems: [{ subsystem_key, roles: [...] }] }
   */
  async getPermissionCatalog() {
    const result = await pool.query(
      `SELECT role_key, role_name_zh, role_name_en, description, permission_keys, subsystem_key
         FROM auth_role
         WHERE deleted = FALSE
         ORDER BY subsystem_key, sort_order`,
    );

    const bySubsystem = new Map<string, any[]>();
    for (const row of result.rows) {
      const key: string = row.subsystem_key;
      if (!bySubsystem.has(key)) bySubsystem.set(key, []);
      bySubsystem.get(key)!.push({
        role_key: row.role_key,
        name_zh: row.role_name_zh,
        name_en: row.role_name_en,
        description_zh: row.description,
        description_en: row.description,
        permissions: Array.isArray(row.permission_keys) ? row.permission_keys : [],
      });
    }

    return {
      version: '1.0.0',
      generated_at: new Date().toISOString(),
      subsystems: Array.from(bySubsystem.entries()).map(([subsystem_key, roles]) => ({
        subsystem_key,
        roles,
      })),
    };
  }

  /**
   * I2: 用户/角色同步 upsert by external_id
   * 事务内完成：角色校验 → 本地账号冲突保护 → SSO 账号冲突保护 → 部门名→code → upsert → 角色整体替换
   */
  async upsertUser(dto: any, appKey: string, operatorId?: string) {
    const client = await pool.connect();
    let syncAction = 'updated';
    let userUuid = '';
    try {
      await client.query('BEGIN');

      // 1. 校验 roles: (role_key, subsystem_key) 二元组
      const requestedRoles: Array<{ subsystem_key: string; role_key: string }> =
        Array.isArray(dto.roles) ? dto.roles : [];
      if (requestedRoles.length === 0) {
        throw new BadRequestException({ code: 'UNKNOWN_ROLE', invalid_roles: [] });
      }
      const roleInClause = requestedRoles
        .map((_, i) => `($${i * 2 + 1}, $${i * 2 + 2})`)
        .join(', ');
      const roleParams = requestedRoles.flatMap(r => [r.role_key, r.subsystem_key]);
      const roleResult = await client.query(
        `SELECT role_key, subsystem_key FROM auth_role
           WHERE (role_key, subsystem_key) IN (${roleInClause})
             AND deleted = FALSE`,
        roleParams,
      );
      const foundRoles = new Set(
        roleResult.rows.map((r: any) => `${r.role_key}|${r.subsystem_key}`),
      );
      const invalidRoles = requestedRoles.filter(
        r => !foundRoles.has(`${r.role_key}|${r.subsystem_key}`),
      );
      if (invalidRoles.length > 0) {
        throw new BadRequestException({ code: 'UNKNOWN_ROLE', invalid_roles: invalidRoles });
      }

      // 2a. 本地账号冲突保护（username/email 命中 local 账号）
      const localConflict = await client.query(
        `SELECT id FROM auth_user
           WHERE (username = $1 OR email = $2)
             AND auth_method = 'local' AND deleted = FALSE`,
        [dto.username, dto.email],
      );
      if (localConflict.rows.length > 0) {
        throw new ConflictException({ code: 'USER_CONFLICT_LOCAL' });
      }
      // 2b. SSO 账号间冲突：同 username/email 但不同 external_id
      const ssoConflict = await client.query(
        `SELECT id FROM auth_user
           WHERE (username = $1 OR email = $2)
             AND auth_method = 'sso' AND sso_provider = 'workos'
             AND external_id <> $3 AND deleted = FALSE`,
        [dto.username, dto.email, dto.external_id],
      );
      if (ssoConflict.rows.length > 0) {
        throw new ConflictException({ code: 'USERNAME_OR_EMAIL_EXISTS' });
      }

      // 3. department 名 → dept_code
      let deptCode: string | null = null;
      if (dto.department) {
        const deptResult = await client.query(
          `SELECT dept_code FROM auth_department
             WHERE (dept_name_zh = $1 OR dept_name_en = $1)
               AND deleted = FALSE
             LIMIT 1`,
          [dto.department],
        );
        if (deptResult.rows.length > 0) deptCode = deptResult.rows[0].dept_code;
      }

      // 4. upsert by external_id + sso_provider=workos
      const status = dto.status === 'disabled' ? 'inactive' : 'active';
      const existing = await client.query(
        `SELECT id, user_uuid FROM auth_user
           WHERE external_id = $1 AND sso_provider = 'workos' AND deleted = FALSE`,
        [dto.external_id],
      );
      let userId: number;
      if (existing.rows.length > 0) {
        const r = existing.rows[0];
        userId = r.id;
        userUuid = r.user_uuid;
        await client.query(
          `UPDATE auth_user
             SET name_zh = $1, name_en = $2, email = $3, dept_code = $4,
                 status = $5, updated_at = NOW()
           WHERE id = $6`,
          [
            dto.name_zh ?? null,
            dto.name_en ?? null,
            dto.email,
            deptCode,
            status,
            userId,
          ],
        );
        syncAction = 'updated';
      } else {
        userUuid = randomUUID();
        const insertResult = await client.query(
          `INSERT INTO auth_user
             (user_uuid, username, email, password_hash, name_zh, name_en,
              dept_code, auth_method, sso_provider, external_id, status)
           VALUES ($1, $2, $3, NULL, $4, $5, $6, 'sso', 'workos', $7, $8)
           RETURNING id`,
          [
            userUuid,
            dto.username,
            dto.email,
            dto.name_zh ?? null,
            dto.name_en ?? null,
            deptCode,
            dto.external_id,
            status,
          ],
        );
        userId = insertResult.rows[0].id;
        syncAction = 'created';
      }

      // 5. 角色整体替换（用已校验过的二元组重新查 role_id）
      await client.query(`DELETE FROM auth_user_role WHERE user_id = $1`, [userId]);
      const inClause = requestedRoles
        .map((_, i) => `($${i * 2 + 3}, $${i * 2 + 4})`)
        .join(', ');
      await client.query(
        `INSERT INTO auth_user_role (user_id, role_id, assigned_by, assigned_at)
           SELECT $1, role_id, $2, NOW()
           FROM auth_role
           WHERE (role_key, subsystem_key) IN (${inClause})`,
        [userId, appKey, ...requestedRoles.flatMap(r => [r.role_key, r.subsystem_key])],
      );

      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }

    // 7. 审计（不阻塞主链路）
    this.auditService
      .log({
        operator: { userId: appKey, username: operatorId ?? undefined },
        action: 'INTEGRATION_USER_UPSERT',
        module: 'integration',
        targetType: 'user',
        targetId: dto.external_id,
        success: true,
        params: {
          external_id: dto.external_id,
          username: dto.username,
          email: dto.email,
          roles: dto.roles,
          status: dto.status,
          sync_action: syncAction,
        },
      })
      .catch(err => {
        this.logger.warn(`upsertUser audit failed: ${(err as Error).message}`);
      });

    return {
      external_id: dto.external_id,
      user_uuid: userUuid,
      sync_action: syncAction,
    };
  }

  /**
   * I3: 保单咨询匹配
   * 单条 SQL 聚合：insurance_carrier ⋈ carrier_partnership ⋈ insurance_product
   * 入参校验：line_of_business ∈ {AUTO,HOME,LIFE,HEALTH,SURETY,COMMERCIAL}；state 大写二字；
   *           product_code 与 keyword 互斥；sub_line/coverages 可选（不传=无特殊要求）
   */
  async matchConsultation(dto: any, appKey: string) {
    const start = Date.now();

    const lob = String(dto.line_of_business || '').toUpperCase();
    const allowedLobs = ['AUTO', 'HOME', 'LIFE', 'HEALTH', 'SURETY', 'COMMERCIAL'];
    if (!allowedLobs.includes(lob)) {
      throw new BadRequestException({ code: 'INVALID_LINE_OF_BUSINESS' });
    }
    const state = String(dto.state || '').toUpperCase();
    if (!/^[A-Z]{2}$/.test(state)) {
      throw new BadRequestException({ code: 'INVALID_STATE' });
    }
    if (dto.product_code && dto.keyword) {
      throw new BadRequestException({ code: 'PRODUCT_CODE_AND_KEYWORD_MUTEX' });
    }
    // 子险种（可选）：非空时按大小写不敏感精确过滤
    const subLine = dto.sub_line != null ? String(dto.sub_line).trim() : '';
    // 主要承保范围（可选）：数组，每个值为产品必须包含的承保范围（AND 语义，大小写不敏感）
    let coverages: string[] = [];
    if (dto.coverages != null) {
      if (!Array.isArray(dto.coverages) || dto.coverages.some((c: unknown) => typeof c !== 'string')) {
        throw new BadRequestException({ code: 'INVALID_COVERAGES' });
      }
      coverages = dto.coverages.map((c: string) => String(c).trim()).filter(Boolean);
    }

    const params: any[] = [lob, state];
    let extraWhere = '';
    let pi = 3;
    if (dto.product_code) {
      extraWhere += ` AND p.product_code = $${pi++}`;
      params.push(dto.product_code);
    }
    if (dto.keyword) {
      extraWhere += ` AND (p.product_name ILIKE $${pi} OR p.short_name ILIKE $${pi})`;
      params.push(`%${dto.keyword}%`);
      pi++;
    }
    if (subLine) {
      extraWhere += ` AND UPPER(p.sub_line) = UPPER($${pi++})`;
      params.push(subLine);
    }
    for (const cov of coverages) {
      extraWhere += ` AND EXISTS (SELECT 1 FROM jsonb_array_elements_text(p.coverages) AS cov(val) WHERE LOWER(cov.val) = LOWER($${pi++}))`;
      params.push(cov);
    }

    const result = await pool.query(
      `SELECT
         c.carrier_id, c.naic_code, c.carrier_name, c.carrier_name_short,
         c.website, c.carrier_type AS admitted, c.am_best_rating AS rating,
         c.coop_status, c.contract_expiry, c.lines,
         p.product_id, p.product_code, p.product_name, p.short_name,
         p.available_states, p.effective_date, p.product_type, p.line_of_business, p.sub_line, p.coverages,
         p.underwriting_mode, p.max_policy_limit, p.age_min, p.age_max,
         p.exclude_dui, p.refer_high_value, p.refer_threshold, p.blacklist_conditions,
         p.description, p.description_en,
         pt.status AS partnership_status, pt.notes, pt.notes_en
       FROM insurance_carrier c
       JOIN carrier_partnership pt
         ON pt.carrier_id = c.carrier_id AND pt.status = 'Active'
       JOIN insurance_product p ON p.carrier_id = c.carrier_id
       WHERE c.deleted = FALSE AND p.deleted = FALSE
         AND c.coop_status = 'active' AND (c.contract_expiry >= CURRENT_DATE OR c.contract_expiry IS NULL)
         AND p.is_active = TRUE AND p.status = 'Active'
         AND UPPER(p.line_of_business) = $1
         AND EXISTS (SELECT 1 FROM jsonb_array_elements_text(p.available_states) AS s(state) WHERE s.state = $2)
         ${extraWhere}`,
      params,
    );

    const lang = String(dto.lang || '');
    const pickZh = (zh: any, _en: any) => zh;
    const pickEn = (_zh: any, en: any) => en ?? _zh;
    const pickField = lang === 'zh-CN' ? pickZh : lang === 'en-US' ? pickEn : (zh: any, en: any) => (en ?? zh);

    const insurerMap = new Map<string, any>();
    const products: any[] = [];
    const underwritingPoints: any[] = [];

    for (const row of result.rows) {
      if (!insurerMap.has(row.carrier_id)) {
        insurerMap.set(row.carrier_id, {
          carrier_id: row.carrier_id,
          naic_code: row.naic_code,
          carrier_name: row.carrier_name_short || row.carrier_name,
          carrier_name_short: row.carrier_name_short,
          website: row.website,
          admitted: row.admitted,
          rating: row.rating,
          coop_status: row.coop_status,
          contract_expiry: row.contract_expiry ? new Date(row.contract_expiry).toISOString().slice(0, 10) : null,
          lines: row.lines,
        });
      }

      products.push({
        product_id: row.product_id,
        product_code: row.product_code,
        product_name: pickField(row.product_name, row.short_name || row.product_name),
        short_name: row.short_name,
        carrier_id: row.carrier_id,
        available_states: row.available_states,
        effective_date: row.effective_date ? new Date(row.effective_date).toISOString().slice(0, 10) : null,
        product_type: row.product_type,
        line_of_business: row.line_of_business,
        sub_line: row.sub_line ?? null,
        coverages: Array.isArray(row.coverages) ? row.coverages : [],
        partnership_status: row.partnership_status,
        notes: pickField(row.notes, row.notes_en),
      });

      // 核保要点提炼（双语 fallback：有 underwriting_mode/max_policy_limit 等结构化字段时组装；否则用 description）
      const points: string[] = [];
      if (row.underwriting_mode) points.push(`underwriting_mode=${row.underwriting_mode}`);
      if (row.max_policy_limit) points.push(`max_policy_limit=${row.max_policy_limit}`);
      if (row.age_min != null || row.age_max != null) {
        points.push(`age=${row.age_min ?? ''}-${row.age_max ?? ''}`);
      }
      if (row.exclude_dui) points.push('exclude_dui=true');
      if (row.refer_high_value) {
        points.push(`refer_high_value@${row.refer_threshold ?? ''}`);
      }
      if (Array.isArray(row.blacklist_conditions) && row.blacklist_conditions.length > 0) {
        points.push(`blacklist=${row.blacklist_conditions.join(',')}`);
      }
      if (points.length === 0) {
        const fallbackDesc = pickField(row.description, row.description_en);
        if (fallbackDesc) points.push(String(fallbackDesc));
      }
      if (points.length > 0) {
        underwritingPoints.push({
          product_id: row.product_id,
          product_code: row.product_code,
          points,
        });
      }
    }

    const durationMs = Date.now() - start;
    this.auditService
      .log({
        operator: { userId: appKey },
        action: 'INTEGRATION_CONSULTATION_MATCH',
        module: 'integration',
        targetType: 'consultation',
        targetId: null,
        success: true,
        params: { ...dto, hit_count: products.length, duration_ms: durationMs },
      })
      .catch(err => {
        this.logger.warn(`matchConsultation audit failed: ${(err as Error).message}`);
      });

    return {
      insurers: Array.from(insurerMap.values()),
      products,
      underwriting_points: underwritingPoints,
    };
  }
}
