import { IsString, IsOptional, IsIn, IsInt, Min, Max, IsNotEmpty } from 'class-validator';

export class CreateIntegrationAppDto {
  @IsString()
  @IsNotEmpty()
  appName: string;

  @IsOptional()
  @IsString()
  appDesc?: string;

  @IsOptional()
  @IsString()
  ipWhitelist?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(10000)
  rateLimit?: number;
}

export class UpdateIntegrationAppDto {
  @IsOptional()
  @IsString()
  appName?: string;

  @IsOptional()
  @IsString()
  appDesc?: string;

  @IsOptional()
  @IsString()
  ipWhitelist?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(10000)
  rateLimit?: number;

  @IsOptional()
  @IsIn(['active', 'disabled'])
  status?: string;
}
